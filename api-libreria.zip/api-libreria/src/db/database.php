<?php

require_once '../src/models/Usuarios.php';

class DatabaseController {

    public function ObtenerTodos() {
        $modeloUsuario = new indira_practica3();
        try {
            $result = $modeloUsuario->getAll();
            echo json_encode(["Resultado" => $result]);
        } catch (Exception $e) {
            echo json_encode(["Error" => $e->getMessage()]);
        }
    }

    /**
     * Obtiene el usuario por su id
     * @param int $id El id del usuario a obtener
     *
     * @return void
     */
    public function ObtenerPorId($id) {
        if (!is_numeric($id)) {
            echo json_encode(["Error" => "ID inválido"]);
            return;
        }

        $modeloUsuario = new indira_practica3();
        try {
            $result = $modeloUsuario->getById($id);
            echo json_encode(["Resultado" => $result]);
        } catch (Exception $e) {
            echo json_encode(["Error" => $e->getMessage()]);
        }
    }
}
